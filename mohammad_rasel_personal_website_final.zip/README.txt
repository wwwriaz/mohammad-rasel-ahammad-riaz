MOHAMMAD RASEL AHAMMAD RIAZ — Final Personal Website

Included:
- Supplied profile photo: IMG_2854.png
- Facebook, Instagram and YouTube links
- WhatsApp: +971 50 813 6302
- Email: rasel878768@gmail.com
- Responsive premium design

TikTok was left as a placeholder because no TikTok URL was provided.
